﻿namespace truYum.Controllers
{
    internal class CategoryModel
    {
    }
}